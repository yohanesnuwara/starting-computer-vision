# Cactus Detection > 2022-07-17 12:12pm
https://universe.roboflow.com/object-detection/cactus-detection

Provided by Roboflow
License: CC BY 4.0

